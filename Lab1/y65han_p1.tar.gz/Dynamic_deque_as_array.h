#ifndef DYNAMIC_DEQUE_AS_ARRAY_H
#define DYNAMIC_DEQUE_AS_ARRAY_H



#include "ece250.h"
#include "Exception.h"


class Dynamic_deque_as_array
{

	public:
		Dynamic_deque_as_array( int = 10 );
		~Dynamic_deque_as_array();


		int head() const;
		int tail() const;
		int size() const;
		bool empty() const;
		int capacity() const;

		void enqueue_head( const int & );
		void enqueue_tail( const int & );
		int dequeue_head();
		int dequeue_tail();
		void clear();
    
    int* array;
    int arrayhead;
    int arraytail;
    int count;
    int arraysize;
    
};


Dynamic_deque_as_array::Dynamic_deque_as_array( int n) {
    if (n < 1){
        arraysize = 1;
    }
    else{
        arraysize = n;
    }
    array = new int[arraysize];
    this->arrayhead = 0;
    this->arraytail = 0;
    count = 0;

}




Dynamic_deque_as_array::~Dynamic_deque_as_array() {
    delete [] array;
}





int Dynamic_deque_as_array::size() const {
    return count;
}


int Dynamic_deque_as_array::capacity() const {
    return arraysize;
}


bool Dynamic_deque_as_array::empty() const {
    bool flag = false;
        if(count == 0){
            flag = true;
        }
        else{
            flag = false;
        }
    return flag;
}


int Dynamic_deque_as_array::head() const {
    if (!empty()){
        return array[arrayhead];
    }
    else{
        throw underflow();
        }
}


int Dynamic_deque_as_array::tail() const {
    if (!empty()){
        return array[arraytail];
    }
    else{
        throw underflow();
    }
}



void Dynamic_deque_as_array::enqueue_head( const int &obj ) {
    if (count != arraysize){                   //check if array is full
        if(!empty()){
            /*if(arrayhead != 0){
                arrayhead--;
            }
            else{
                arrayhead  = arraysize - 1;
            }*/
            arrayhead = ((arrayhead - 1) + arraysize) % arraysize;
        }
        else{
                arrayhead = 0;
                arraytail = 0;
        }
        array[arrayhead] = obj;
        count++;
    }
    else{
        arraysize = arraysize * 2;
        int* newarray = new int[arraysize];
        if(arrayhead <= arraytail){
            for (int i = 0; i < arraysize/2; i++){
                newarray[i] = array[i];
            }
        }
        else{
            int tmp = 0;
            for(int i = arrayhead; i < arraysize/2; i++){
                newarray[tmp] = array[i];
                tmp++;
            }
            for(int j = 0; j <= arraytail; j++){
                newarray[tmp] = array[j];
                tmp++;
            }
        }
        
        arrayhead = 0;
        arraytail = count - 1;
        delete [] array;
        array = newarray;
        enqueue_head(obj);
    }
}


void Dynamic_deque_as_array::enqueue_tail( const int &obj ) {
    if (count != arraysize){
        if(!empty()){
            /*if(arraytail != arraysize - 1){
                arraytail++;
            }
            else{
                arraytail  = 0;
            }*/
            arraytail = ((arraytail + 1) + arraysize) % arraysize;
        }
        else{
            arrayhead = 0;
            arraytail = 0;
        }
        array[arraytail] = obj;
        count++;
    }
    else{
        arraysize = arraysize * 2;
        int* newarray = new int[arraysize];
        if(arrayhead <= arraytail){
            for (int i = 0; i < arraysize/2; i++){
                newarray[i] = array[i];
            }
        }
        else{
            int tmp = 0;
            for(int i = arrayhead; i < arraysize/2; i++){
                newarray[tmp] = array[i];
                tmp++;
            }
            for(int j = 0; j <= arraytail; j++){
                newarray[tmp] = array[j];
                tmp++;
            }
        }
        
        arrayhead = 0;
        arraytail = count - 1;
        delete [] array;
        array = newarray;
        enqueue_tail(obj);
    }

}


int Dynamic_deque_as_array::dequeue_head() {
    int oldhead = 0;
    if(!empty()){
        oldhead = array[arrayhead];
        array[arrayhead] = 0;
        arrayhead = ((arrayhead + 1) + arraysize) % arraysize;
        count--;
        
    }
    else{
        throw underflow();
    }
	return oldhead;

}

int Dynamic_deque_as_array::dequeue_tail() {
    int oldtail = 0;
    if(!empty()){
        oldtail = array[arraytail];
        array[arraytail] = 0;
        arraytail = ((arraytail - 1) + arraysize) % arraysize;
        count--;
    }
    else{
        throw underflow();
    }
	return oldtail;
}


void Dynamic_deque_as_array::clear() {
    //for(int i = 0; i < arraysize; i++){
        //array[i] = 0;
        count = 0;
    //}
    arrayhead = 0;
    arraytail = 0;
}

#endif
